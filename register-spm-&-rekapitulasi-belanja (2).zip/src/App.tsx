import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Navbar } from './components/Navbar';
import { Sidebar } from './components/Sidebar';
import { LoginModal } from './components/LoginModal';
import { DashboardView } from './components/dashboard/DashboardView';
import { RegisterSpmView } from './components/spm/RegisterSpmView';
import { PekerjaanBelumSelesaiView } from './components/pekerjaan/PekerjaanBelumSelesaiView';
import { RekapBidangView } from './components/rekap/RekapBidangView';
import { RekapRekeningView } from './components/rekap/RekapRekeningView';
import { RekapPajakView } from './components/rekap/RekapPajakView';
import { MasterDataView } from './components/master/MasterDataView';

const MainContent: React.FC = () => {
  const { currentView, user, isLoginModalOpen, setIsLoginModalOpen } = useApp();

  const renderView = () => {
    switch (currentView) {
      case 'dashboard':
        return <DashboardView />;
      case 'spm':
      case 'register_spm':
        return <RegisterSpmView />;
      case 'pekerjaan':
      case 'pekerjaan_belum_selesai':
        return <PekerjaanBelumSelesaiView />;
      case 'rekap_bidang':
        return <RekapBidangView />;
      case 'rekap_rekening':
        return <RekapRekeningView />;
      case 'rekap_pajak':
        return <RekapPajakView />;
      case 'master':
      case 'master_bidang':
      case 'master_program':
      case 'master_kegiatan':
      case 'master_subkegiatan':
      case 'master_rekening':
      case 'master_kontrak':
      case 'master_user':
      case 'master_spreadsheet':
        return <MasterDataView />;
      default:
        return <DashboardView />;
    }
  };

  return (
    <div className="min-h-screen bg-slate-100 flex flex-col font-sans text-slate-900 antialiased selection:bg-amber-400 selection:text-slate-950">
      <Navbar />

      <div className="flex-1 flex overflow-hidden">
        <Sidebar />

        <div className="flex-1 lg:pl-72 overflow-y-auto min-w-0 w-full">
          <main className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto w-full min-w-0">
            {renderView()}
          </main>
        </div>
      </div>

      {isLoginModalOpen && (
        <LoginModal onClose={() => setIsLoginModalOpen(false)} />
      )}
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <MainContent />
    </AppProvider>
  );
}
