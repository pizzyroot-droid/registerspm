import * as XLSX from 'xlsx';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { formatRupiah, formatDateIndo } from './formatters';

export function exportTableToExcel(
  title: string,
  headers: string[],
  rows: (string | number)[][],
  filename: string
) {
  // Create worksheet
  const wsData = [
    [title.toUpperCase()],
    [`Tanggal Cetak: ${formatDateIndo(new Date().toISOString())}`],
    [], // Blank row
    headers,
    ...rows,
  ];

  const ws = XLSX.utils.aoa_to_sheet(wsData);

  // Set header styling / column widths
  const colWidths = headers.map((h, colIndex) => {
    let maxLen = h.length;
    rows.forEach((row) => {
      const val = row[colIndex] !== undefined ? String(row[colIndex]) : '';
      if (val.length > maxLen) maxLen = val.length;
    });
    return { wch: Math.min(Math.max(maxLen + 3, 12), 50) };
  });

  ws['!cols'] = colWidths;

  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'Laporan');

  XLSX.writeFile(wb, `${filename}_${new Date().toISOString().slice(0, 10)}.xlsx`);
}

export function exportTableToPdf(
  title: string,
  subtitle: string,
  headers: string[],
  rows: (string | number)[][],
  filename: string,
  orientation: 'p' | 'l' = 'l' // default landscape for wide accounting tables
) {
  const doc = new jsPDF({
    orientation: orientation,
    unit: 'mm',
    format: 'a4',
  });

  // Header Title
  doc.setFontSize(14);
  doc.setFont('helvetica', 'bold');
  doc.text(title.toUpperCase(), doc.internal.pageSize.getWidth() / 2, 15, {
    align: 'center',
  });

  if (subtitle) {
    doc.setFontSize(10);
    doc.setFont('helvetica', 'normal');
    doc.text(subtitle, doc.internal.pageSize.getWidth() / 2, 21, {
      align: 'center',
    });
  }

  doc.setFontSize(8);
  doc.text(
    `Dicetak pada: ${formatDateIndo(new Date().toISOString())}`,
    14,
    27
  );

  autoTable(doc, {
    startY: 30,
    head: [headers],
    body: rows,
    theme: 'grid',
    headStyles: {
      fillColor: [30, 41, 59], // Slate 800
      textColor: [255, 255, 255],
      fontSize: 8,
      fontStyle: 'bold',
      halign: 'center',
    },
    bodyStyles: {
      fontSize: 7.5,
      textColor: [30, 30, 30],
    },
    alternateRowStyles: {
      fillColor: [248, 250, 252],
    },
    margin: { top: 30, right: 14, bottom: 15, left: 14 },
    styles: {
      overflow: 'linebreak',
      cellPadding: 2,
    },
  });

  // Footer page numbers
  const pageCount = (doc as any).internal.getNumberOfPages();
  for (let i = 1; i <= pageCount; i++) {
    doc.setPage(i);
    doc.setFontSize(8);
    doc.setTextColor(120, 120, 120);
    doc.text(
      `Halaman ${i} dari ${pageCount}`,
      doc.internal.pageSize.getWidth() - 25,
      doc.internal.pageSize.getHeight() - 8
    );
  }

  doc.save(`${filename}_${new Date().toISOString().slice(0, 10)}.pdf`);
}
