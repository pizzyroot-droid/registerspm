import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Lock, User, FileSpreadsheet, ShieldAlert } from 'lucide-react';

export const LoginModal: React.FC = () => {
  const { login } = useApp();
  const [usernameInput, setUsernameInput] = useState('');
  const [passwordInput, setPasswordInput] = useState('');
  const [errorMsg, setErrorMsg] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    const success = login(usernameInput.trim(), passwordInput);
    if (!success) {
      setErrorMsg('Username atau password yang Anda masukkan salah.');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/80 backdrop-blur-sm p-4">
      <div className="w-full max-w-md bg-white rounded-2xl shadow-2xl border border-slate-100 overflow-hidden">
        {/* Top Decorative Banner */}
        <div className="bg-gradient-to-r from-slate-900 via-sky-950 to-slate-900 p-8 text-center relative">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-sky-500/20 text-sky-400 border border-sky-400/30 mb-3 shadow-inner">
            <FileSpreadsheet className="w-9 h-9" />
          </div>
          <h1 className="text-xl font-bold text-white tracking-wide">
            REGISTER SPM & REKAPITULASI
          </h1>
          <p className="text-xs text-sky-200 mt-1 font-medium">
            Sistem Informasi Manajemen Belanja Daerah
          </p>
        </div>

        {/* Login Form */}
        <form onSubmit={handleSubmit} className="p-8 space-y-5">
          <div className="text-center mb-2">
            <h2 className="text-lg font-bold text-slate-800">Masuk ke Sistem</h2>
            <p className="text-xs text-slate-500">Silakan masukkan akun pengelola Anda</p>
          </div>

          {errorMsg && (
            <div className="flex items-center gap-2 p-3 text-xs text-rose-700 bg-rose-50 border border-rose-200 rounded-xl">
              <ShieldAlert className="w-4 h-4 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          <div className="space-y-1.5">
            <label className="block text-xs font-semibold text-slate-700">Username</label>
            <div className="relative">
              <User className="absolute left-3.5 top-3 w-4 h-4 text-slate-400" />
              <input
                type="text"
                required
                value={usernameInput}
                onChange={(e) => setUsernameInput(e.target.value)}
                placeholder="Masukkan Username"
                className="w-full pl-10 pr-4 py-2.5 text-sm bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-sky-600/20 focus:border-sky-600 transition-all text-slate-800"
              />
            </div>
          </div>

          <div className="space-y-1.5">
            <label className="block text-xs font-semibold text-slate-700">Password</label>
            <div className="relative">
              <Lock className="absolute left-3.5 top-3 w-4 h-4 text-slate-400" />
              <input
                type="password"
                required
                value={passwordInput}
                onChange={(e) => setPasswordInput(e.target.value)}
                placeholder="Masukkan Password"
                className="w-full pl-10 pr-4 py-2.5 text-sm bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-sky-600/20 focus:border-sky-600 transition-all text-slate-800"
              />
            </div>
          </div>

          <button
            type="submit"
            className="w-full py-3 px-4 bg-sky-700 hover:bg-sky-800 text-white font-semibold rounded-xl text-sm shadow-md hover:shadow-lg transition-all focus:outline-none focus:ring-2 focus:ring-sky-500/50 active:scale-[0.99] cursor-pointer"
          >
            Masuk Sekarang
          </button>
        </form>
      </div>
    </div>
  );
};
