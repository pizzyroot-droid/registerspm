import React, { useState, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import { RegisterSpm, FilterSpm } from '../../types';
import { formatRupiah, formatDateIndo } from '../../utils/formatters';
import { exportTableToExcel, exportTableToPdf } from '../../utils/exporters';
import { SpmFormModal } from './SpmFormModal';
import { SpmDetailModal } from './SpmDetailModal';
import {
  FileCheck2,
  Plus,
  FileSpreadsheet,
  FileText,
  Search,
  Filter,
  Eye,
  Edit2,
  Trash2,
  Layers,
  Calendar,
} from 'lucide-react';

export const RegisterSpmView: React.FC = () => {
  const {
    selectedYear,
    spmList,
    bidangList,
    kontrakList,
    deleteSpm,
  } = useApp();

  // Modals state
  const [showFormModal, setShowFormModal] = useState(false);
  const [spmToEdit, setSpmToEdit] = useState<RegisterSpm | null>(null);
  const [selectedSpmDetail, setSelectedSpmDetail] = useState<RegisterSpm | null>(null);

  // Filters State
  const [filter, setFilter] = useState<FilterSpm>({
    startDate: '',
    endDate: '',
    searchQuery: '',
    bidangId: 'all',
    jenisBelanja: 'all',
    limit: 20,
  });

  // Filtered SPM list
  const filteredSpm = useMemo(() => {
    return spmList
      .filter((s) => s.tahun === selectedYear)
      .filter((s) => {
        // Date range filter
        if (filter.startDate && new Date(s.tanggalSpm) < new Date(filter.startDate)) return false;
        if (filter.endDate && new Date(s.tanggalSpm) > new Date(filter.endDate)) return false;

        // Search query filter (No SPM / Uraian / Kontrak)
        if (filter.searchQuery.trim()) {
          const q = filter.searchQuery.toLowerCase();
          const k = kontrakList.find((item) => item.id === s.kontrakId);
          const matchNoSpm = s.nomorSpm.toLowerCase().includes(q);
          const matchUraian = s.uraianPekerjaan.toLowerCase().includes(q);
          const matchKontrak = k
            ? k.nomorKontrak.toLowerCase().includes(q) || k.uraian.toLowerCase().includes(q)
            : false;
          if (!matchNoSpm && !matchUraian && !matchKontrak) return false;
        }

        // Bidang filter
        if (filter.bidangId !== 'all' && s.bidangId !== filter.bidangId) return false;

        // Jenis Belanja filter
        if (filter.jenisBelanja !== 'all' && s.jenisBelanja !== filter.jenisBelanja) return false;

        return true;
      })
      .slice(0, filter.limit === 0 ? undefined : filter.limit);
  }, [spmList, selectedYear, filter, kontrakList]);

  // Export Excel
  const handleExportExcel = () => {
    const headers = [
      'No',
      'Nomor SPM',
      'Tgl SPM',
      'Jenis Belanja',
      'Bidang',
      'Uraian Pekerjaan',
      'Detail Kontrak',
      'Fisik %',
      'Realisasi SPM (Rp)',
      'Total Pajak (Rp)',
    ];

    const rows = filteredSpm.map((s, idx) => {
      const b = bidangList.find((item) => item.id === s.bidangId);
      const k = kontrakList.find((item) => item.id === s.kontrakId);
      const totalPajak =
        (s.pajak?.ppn || 0) +
        (s.pajak?.pph21 || 0) +
        (s.pajak?.pph22 || 0) +
        (s.pajak?.pph23 || 0) +
        (s.pajak?.pphPasal4 || 0);

      return [
        idx + 1,
        s.nomorSpm,
        formatDateIndo(s.tanggalSpm),
        s.jenisBelanja,
        b?.nama || '-',
        s.uraianPekerjaan,
        k ? `${k.nomorKontrak} (${k.namaPenyedia})` : 'Non-Kontraktual',
        `${s.persentaseFisik}%`,
        s.realisasiSpm,
        totalPajak,
      ];
    });

    exportTableToExcel(
      `REGISTER SPM TAHUN ANGGARAN ${selectedYear}`,
      headers,
      rows,
      `Register_SPM_${selectedYear}`
    );
  };

  // Export PDF
  const handleExportPdf = () => {
    const headers = [
      'NO',
      'NOMOR & TGL SPM',
      'JENIS',
      'BIDANG',
      'URAIAN PEKERJAAN',
      'DETAIL KONTRAK',
      'FISIK %',
      'REALISASI SPM',
      'PAJAK',
    ];

    const rows = filteredSpm.map((s, idx) => {
      const b = bidangList.find((item) => item.id === s.bidangId);
      const k = kontrakList.find((item) => item.id === s.kontrakId);
      const totalPajak =
        (s.pajak?.ppn || 0) +
        (s.pajak?.pph21 || 0) +
        (s.pajak?.pph22 || 0) +
        (s.pajak?.pph23 || 0) +
        (s.pajak?.pphPasal4 || 0);

      return [
        idx + 1,
        `${s.nomorSpm}\n${formatDateIndo(s.tanggalSpm)}`,
        s.jenisBelanja,
        b?.nama || '-',
        s.uraianPekerjaan,
        k ? `${k.uraian}\nNo: ${k.nomorKontrak}` : '-',
        `${s.persentaseFisik}%`,
        formatRupiah(s.realisasiSpm),
        formatRupiah(totalPajak),
      ];
    });

    exportTableToPdf(
      `REGISTER SPM TAHUN ANGGARAN ${selectedYear}`,
      'Pemerintah Daerah - Register Pencairan Belanja SPM',
      headers,
      rows,
      `Register_SPM_${selectedYear}`,
      'l'
    );
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Top Header Card */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white p-6 rounded-3xl border border-slate-200/80 shadow-xs">
        <div>
          <h2 className="text-xl font-extrabold text-slate-900 flex items-center gap-2">
            <FileCheck2 className="w-6 h-6 text-sky-600" />
            Register Surat Perintah Membayar (SPM)
          </h2>
          <p className="text-xs text-slate-500 mt-1">
            Kelola pencairan SPM, rincian objek belanja per bidang, dan potongan pajak daerah.
          </p>
        </div>

        {/* Top Buttons: Input & Export */}
        <div className="flex items-center flex-wrap gap-2.5">
          <button
            onClick={() => {
              setSpmToEdit(null);
              setShowFormModal(true);
            }}
            className="inline-flex items-center gap-2 px-4 py-2.5 bg-sky-700 hover:bg-sky-800 text-white font-bold text-xs rounded-2xl shadow-md transition-all active:scale-[0.98] cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Input SPM Baru</span>
          </button>

          <button
            onClick={handleExportExcel}
            className="inline-flex items-center gap-1.5 px-3.5 py-2.5 bg-emerald-50 text-emerald-700 hover:bg-emerald-100 border border-emerald-200 font-bold text-xs rounded-2xl transition-all cursor-pointer"
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
            <span>Export Excel</span>
          </button>

          <button
            onClick={handleExportPdf}
            className="inline-flex items-center gap-1.5 px-3.5 py-2.5 bg-rose-50 text-rose-700 hover:bg-rose-100 border border-rose-200 font-bold text-xs rounded-2xl transition-all cursor-pointer"
          >
            <FileText className="w-4 h-4 text-rose-600" />
            <span>Export PDF</span>
          </button>
        </div>
      </div>

      {/* Filter Toolbar Box */}
      <div className="bg-white p-5 rounded-3xl border border-slate-200/80 shadow-xs space-y-4">
        <div className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-2">
          <Filter className="w-4 h-4 text-sky-600" />
          Filter Data SPM
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3 text-xs">
          {/* Periode dd/mm/yyyy */}
          <div className="space-y-1">
            <label className="text-[11px] font-bold text-slate-600 flex items-center gap-1">
              <Calendar className="w-3 h-3 text-slate-400" />
              Dari Tanggal
            </label>
            <input
              type="date"
              value={filter.startDate}
              onChange={(e) => setFilter({ ...filter, startDate: e.target.value })}
              className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-sky-500"
            />
          </div>

          <div className="space-y-1">
            <label className="text-[11px] font-bold text-slate-600 flex items-center gap-1">
              <Calendar className="w-3 h-3 text-slate-400" />
              Sampai Tanggal
            </label>
            <input
              type="date"
              value={filter.endDate}
              onChange={(e) => setFilter({ ...filter, endDate: e.target.value })}
              className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-sky-500"
            />
          </div>

          {/* Search No SPM / Uraian / Kontrak */}
          <div className="space-y-1 sm:col-span-2 lg:col-span-1">
            <label className="text-[11px] font-bold text-slate-600">Pencarian SPM / Kontrak</label>
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
              <input
                type="text"
                value={filter.searchQuery}
                onChange={(e) => setFilter({ ...filter, searchQuery: e.target.value })}
                placeholder="No SPM / Uraian / Kontrak..."
                className="w-full pl-8 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-sky-500"
              />
            </div>
          </div>

          {/* Per Bidang */}
          <div className="space-y-1">
            <label className="text-[11px] font-bold text-slate-600">Per Bidang</label>
            <select
              value={filter.bidangId}
              onChange={(e) => setFilter({ ...filter, bidangId: e.target.value })}
              className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-sky-500 cursor-pointer"
            >
              <option value="all">Semua Bidang</option>
              {bidangList.map((b) => (
                <option key={b.id} value={b.id}>
                  {b.nama}
                </option>
              ))}
            </select>
          </div>

          {/* Per Jenis Belanja & Limit */}
          <div className="space-y-1">
            <label className="text-[11px] font-bold text-slate-600">Jenis Belanja & Limit</label>
            <div className="grid grid-cols-2 gap-1.5">
              <select
                value={filter.jenisBelanja}
                onChange={(e) => setFilter({ ...filter, jenisBelanja: e.target.value })}
                className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-sky-500 cursor-pointer text-xs"
              >
                <option value="all">Semua Jenis</option>
                <option value="LS">LS</option>
                <option value="UP">UP</option>
                <option value="GU">GU</option>
                <option value="TU">TU</option>
                <option value="Gaji dan Tunjangan">Gaji</option>
              </select>

              <select
                value={filter.limit}
                onChange={(e) => setFilter({ ...filter, limit: Number(e.target.value) })}
                className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-sky-500 cursor-pointer text-xs"
              >
                <option value={20}>20 Data</option>
                <option value={50}>50 Data</option>
                <option value={100}>100 Data</option>
                <option value={0}>Semua SPM</option>
              </select>
            </div>
          </div>
        </div>
      </div>

      {/* Main Table Output */}
      <div className="bg-white rounded-3xl border border-slate-200/80 shadow-xs overflow-hidden">
        <div className="p-4 bg-slate-900 text-white flex items-center justify-between text-xs font-bold">
          <div className="flex items-center gap-2">
            <Layers className="w-4 h-4 text-sky-400" />
            <span>
              TAMPILAN HASIL REGISTER SPM (Menampilkan {filteredSpm.length} Data)
            </span>
          </div>
          <span className="text-[11px] text-sky-300 font-medium">Tahun Anggaran {selectedYear}</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-100 text-slate-700 font-extrabold uppercase border-b border-slate-200 text-[11px]">
                <th className="p-3 text-center w-12">NO</th>
                <th className="p-3 min-w-[150px]">NOMOR & TGL SPM</th>
                <th className="p-3 w-20">JENIS</th>
                <th className="p-3 min-w-[140px]">BIDANG</th>
                <th className="p-3 min-w-[200px]">URAIAN PEKERJAAN</th>
                <th className="p-3 min-w-[180px]">DETAIL KONTRAK</th>
                <th className="p-3 text-center w-20">FISIK</th>
                <th className="p-3 text-right min-w-[140px]">REALISASI SPM</th>
                <th className="p-3 text-right min-w-[120px]">PAJAK</th>
                <th className="p-3 text-center min-w-[110px]">AKSI</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200/80">
              {filteredSpm.length === 0 ? (
                <tr>
                  <td colSpan={10} className="p-8 text-center text-slate-400 font-medium">
                    Tidak ada data Register SPM yang sesuai dengan filter.
                  </td>
                </tr>
              ) : (
                filteredSpm.map((spm, idx) => {
                  const bidang = bidangList.find((b) => b.id === spm.bidangId);
                  const kontrak = kontrakList.find((k) => k.id === spm.kontrakId);
                  const totalPajak =
                    (spm.pajak?.ppn || 0) +
                    (spm.pajak?.pph21 || 0) +
                    (spm.pajak?.pph22 || 0) +
                    (spm.pajak?.pph23 || 0) +
                    (spm.pajak?.pphPasal4 || 0);

                  return (
                    <tr key={spm.id} className="hover:bg-sky-50/50 transition-colors">
                      <td className="p-3 text-center font-bold text-slate-500">{idx + 1}</td>
                      <td className="p-3">
                        <div className="font-bold text-slate-900 font-mono">{spm.nomorSpm}</div>
                        <div className="text-[10px] text-slate-500">
                          {formatDateIndo(spm.tanggalSpm)}
                        </div>
                      </td>
                      <td className="p-3">
                        <span className="px-2 py-0.5 bg-sky-100 text-sky-800 font-bold rounded-lg text-[10px]">
                          {spm.jenisBelanja}
                        </span>
                      </td>
                      <td className="p-3 font-semibold text-slate-800">
                        {bidang?.nama || '-'}
                      </td>
                      <td className="p-3 font-medium text-slate-800 max-w-xs line-clamp-2">
                        {spm.uraianPekerjaan}
                      </td>
                      <td className="p-3 text-slate-700">
                        {kontrak ? (
                          <div>
                            <div className="font-bold text-slate-900 text-[11px]">{kontrak.uraian}</div>
                            <div className="text-[10px] text-slate-500">
                              No: {kontrak.nomorKontrak}
                            </div>
                          </div>
                        ) : (
                          <span className="text-slate-400 italic">Non-Kontraktual</span>
                        )}
                      </td>
                      <td className="p-3 text-center font-bold text-indigo-700">
                        {spm.persentaseFisik}%
                      </td>
                      <td className="p-3 text-right font-extrabold text-sky-800">
                        {formatRupiah(spm.realisasiSpm)}
                      </td>
                      <td className="p-3 text-right font-bold text-slate-700">
                        {formatRupiah(totalPajak)}
                      </td>
                      <td className="p-3">
                        <div className="flex items-center justify-center gap-1">
                          <button
                            onClick={() => setSelectedSpmDetail(spm)}
                            className="p-1.5 text-sky-600 hover:bg-sky-100 rounded-lg transition-colors cursor-pointer"
                            title="Lihat Detail SPM"
                          >
                            <Eye className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => {
                              setSpmToEdit(spm);
                              setShowFormModal(true);
                            }}
                            className="p-1.5 text-amber-600 hover:bg-amber-100 rounded-lg transition-colors cursor-pointer"
                            title="Edit SPM"
                          >
                            <Edit2 className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => {
                              if (confirm(`Hapus SPM ${spm.nomorSpm}?`)) {
                                deleteSpm(spm.id);
                              }
                            }}
                            className="p-1.5 text-rose-600 hover:bg-rose-100 rounded-lg transition-colors cursor-pointer"
                            title="Hapus SPM"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Form Modal */}
      {showFormModal && (
        <SpmFormModal
          spmToEdit={spmToEdit}
          onClose={() => {
            setShowFormModal(false);
            setSpmToEdit(null);
          }}
        />
      )}

      {/* Detail Modal */}
      {selectedSpmDetail && (
        <SpmDetailModal
          spm={selectedSpmDetail}
          onClose={() => setSelectedSpmDetail(null)}
        />
      )}
    </div>
  );
};
