import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  TahunAnggaran,
  User,
  Bidang,
  Program,
  Kegiatan,
  SubKegiatan,
  RekeningPagu,
  KontrakPekerjaan,
  RegisterSpm,
  GasConfig,
} from '../types';
import {
  initialUser,
  initialBidang,
  initialProgram,
  initialKegiatan,
  initialSubKegiatan,
  initialRekening,
  initialKontrak,
  initialSpm,
} from '../data/initialData';

interface AppContextType {
  currentView: string;
  setCurrentView: (view: string) => void;
  activeTab: string;
  setActiveTab: (tab: string) => void;
  sidebarOpen: boolean;
  setSidebarOpen: (open: boolean) => void;
  isLoginModalOpen: boolean;
  setIsLoginModalOpen: (open: boolean) => void;

  selectedYear: TahunAnggaran;
  setSelectedYear: (year: TahunAnggaran) => void;
  user: User;
  isLoggedIn: boolean;
  login: (u: string, p: string) => boolean;
  logout: () => void;
  updateUserCredentials: (newUsername: string, newPassword: string) => void;

  // Master Data
  bidangList: Bidang[];
  addBidang: (item: Omit<Bidang, 'id'>) => void;
  updateBidang: (id: string, item: Omit<Bidang, 'id'>) => void;
  deleteBidang: (id: string) => void;

  programList: Program[];
  addProgram: (item: Omit<Program, 'id'>) => void;
  updateProgram: (id: string, item: Omit<Program, 'id'>) => void;
  deleteProgram: (id: string) => void;

  kegiatanList: Kegiatan[];
  addKegiatan: (item: Omit<Kegiatan, 'id'>) => void;
  updateKegiatan: (id: string, item: Omit<Kegiatan, 'id'>) => void;
  deleteKegiatan: (id: string) => void;

  subKegiatanList: SubKegiatan[];
  addSubKegiatan: (item: Omit<SubKegiatan, 'id'>) => void;
  updateSubKegiatan: (id: string, item: Omit<SubKegiatan, 'id'>) => void;
  deleteSubKegiatan: (id: string) => void;

  rekeningList: RekeningPagu[];
  addRekening: (item: Omit<RekeningPagu, 'id'>) => void;
  updateRekening: (id: string, item: Omit<RekeningPagu, 'id'>) => void;
  deleteRekening: (id: string) => void;

  kontrakList: KontrakPekerjaan[];
  addKontrak: (item: Omit<KontrakPekerjaan, 'id'>) => void;
  updateKontrak: (id: string, item: Omit<KontrakPekerjaan, 'id'>) => void;
  deleteKontrak: (id: string) => void;

  spmList: RegisterSpm[];
  addSpm: (item: Omit<RegisterSpm, 'id'>) => void;
  updateSpm: (id: string, item: Omit<RegisterSpm, 'id'>) => void;
  deleteSpm: (id: string) => void;

  // GAS Sync
  gasConfig: GasConfig;
  updateGasConfig: (config: Partial<GasConfig>) => void;
  isSyncing: boolean;
  syncStatusMessage: { type: 'success' | 'error' | 'info'; text: string } | null;
  syncWebToSpreadsheet: () => Promise<boolean>;
  syncSpreadsheetToWeb: () => Promise<boolean>;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const LOCAL_STORAGE_KEY = 'REG_SPM_APP_DATA_V1';

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentView, setCurrentView] = useState<string>('dashboard');
  const [sidebarOpen, setSidebarOpen] = useState<boolean>(false);
  const [isLoginModalOpen, setIsLoginModalOpen] = useState<boolean>(false);

  const [selectedYear, setSelectedYear] = useState<TahunAnggaran>('2026');
  const [isLoggedIn, setIsLoggedIn] = useState<boolean>(() => {
    return localStorage.getItem('REG_SPM_AUTH') === 'true';
  });

  const [user, setUser] = useState<User>(() => {
    const saved = localStorage.getItem('REG_SPM_USER');
    return saved ? JSON.parse(saved) : initialUser;
  });

  const [bidangList, setBidangList] = useState<Bidang[]>(initialBidang);
  const [programList, setProgramList] = useState<Program[]>(initialProgram);
  const [kegiatanList, setKegiatanList] = useState<Kegiatan[]>(initialKegiatan);
  const [subKegiatanList, setSubKegiatanList] = useState<SubKegiatan[]>(initialSubKegiatan);
  const [rekeningList, setRekeningList] = useState<RekeningPagu[]>(initialRekening);
  const [kontrakList, setKontrakList] = useState<KontrakPekerjaan[]>(initialKontrak);
  const [spmList, setSpmList] = useState<RegisterSpm[]>(initialSpm);

  const [gasConfig, setGasConfig] = useState<GasConfig>({
    webAppUrl: '',
    autoSync: false,
  });

  const [isSyncing, setIsSyncing] = useState<boolean>(false);
  const [syncStatusMessage, setSyncStatusMessage] = useState<{
    type: 'success' | 'error' | 'info';
    text: string;
  } | null>(null);

  // Load from local storage on init
  useEffect(() => {
    try {
      const stored = localStorage.getItem(LOCAL_STORAGE_KEY);
      if (stored) {
        const parsed = JSON.parse(stored);
        if (parsed.bidangList) setBidangList(parsed.bidangList);
        if (parsed.programList) setProgramList(parsed.programList);
        if (parsed.kegiatanList) setKegiatanList(parsed.kegiatanList);
        if (parsed.subKegiatanList) setSubKegiatanList(parsed.subKegiatanList);
        if (parsed.rekeningList) setRekeningList(parsed.rekeningList);
        if (parsed.kontrakList) setKontrakList(parsed.kontrakList);
        if (parsed.spmList) setSpmList(parsed.spmList);
        if (parsed.gasConfig) setGasConfig(parsed.gasConfig);
      }
    } catch (e) {
      console.error('Failed to parse localStorage data', e);
    }
  }, []);

  // Save to local storage on change
  useEffect(() => {
    const dataToSave = {
      bidangList,
      programList,
      kegiatanList,
      subKegiatanList,
      rekeningList,
      kontrakList,
      spmList,
      gasConfig,
    };
    localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(dataToSave));
  }, [
    bidangList,
    programList,
    kegiatanList,
    subKegiatanList,
    rekeningList,
    kontrakList,
    spmList,
    gasConfig,
  ]);

  // Auth functions
  const login = (u: string, p: string) => {
    if (u === user.username && p === user.passwordHash) {
      setIsLoggedIn(true);
      localStorage.setItem('REG_SPM_AUTH', 'true');
      return true;
    }
    return false;
  };

  const logout = () => {
    setIsLoggedIn(false);
    localStorage.removeItem('REG_SPM_AUTH');
  };

  const updateUserCredentials = (newUsername: string, newPassword: string) => {
    const updated = { ...user, username: newUsername, passwordHash: newPassword };
    setUser(updated);
    localStorage.setItem('REG_SPM_USER', JSON.stringify(updated));
  };

  // Helper ID generator
  const genId = (prefix: string) => `${prefix}_${Date.now()}_${Math.floor(Math.random() * 1000)}`;

  // CRUD Bidang
  const addBidang = (item: Omit<Bidang, 'id'>) => {
    setBidangList((prev) => [...prev, { ...item, id: genId('B') }]);
  };
  const updateBidang = (id: string, item: Omit<Bidang, 'id'>) => {
    setBidangList((prev) => prev.map((b) => (b.id === id ? { ...item, id } : b)));
  };
  const deleteBidang = (id: string) => {
    setBidangList((prev) => prev.filter((b) => b.id !== id));
  };

  // CRUD Program
  const addProgram = (item: Omit<Program, 'id'>) => {
    setProgramList((prev) => [...prev, { ...item, id: genId('P') }]);
  };
  const updateProgram = (id: string, item: Omit<Program, 'id'>) => {
    setProgramList((prev) => prev.map((p) => (p.id === id ? { ...item, id } : p)));
  };
  const deleteProgram = (id: string) => {
    setProgramList((prev) => prev.filter((p) => p.id !== id));
  };

  // CRUD Kegiatan
  const addKegiatan = (item: Omit<Kegiatan, 'id'>) => {
    setKegiatanList((prev) => [...prev, { ...item, id: genId('K') }]);
  };
  const updateKegiatan = (id: string, item: Omit<Kegiatan, 'id'>) => {
    setKegiatanList((prev) => prev.map((k) => (k.id === id ? { ...item, id } : k)));
  };
  const deleteKegiatan = (id: string) => {
    setKegiatanList((prev) => prev.filter((k) => k.id !== id));
  };

  // CRUD SubKegiatan
  const addSubKegiatan = (item: Omit<SubKegiatan, 'id'>) => {
    setSubKegiatanList((prev) => [...prev, { ...item, id: genId('SK') }]);
  };
  const updateSubKegiatan = (id: string, item: Omit<SubKegiatan, 'id'>) => {
    setSubKegiatanList((prev) => prev.map((sk) => (sk.id === id ? { ...item, id } : sk)));
  };
  const deleteSubKegiatan = (id: string) => {
    setSubKegiatanList((prev) => prev.filter((sk) => sk.id !== id));
  };

  // CRUD Rekening
  const addRekening = (item: Omit<RekeningPagu, 'id'>) => {
    setRekeningList((prev) => [...prev, { ...item, id: genId('R') }]);
  };
  const updateRekening = (id: string, item: Omit<RekeningPagu, 'id'>) => {
    setRekeningList((prev) => prev.map((r) => (r.id === id ? { ...item, id } : r)));
  };
  const deleteRekening = (id: string) => {
    setRekeningList((prev) => prev.filter((r) => r.id !== id));
  };

  // CRUD Kontrak
  const addKontrak = (item: Omit<KontrakPekerjaan, 'id'>) => {
    setKontrakList((prev) => [...prev, { ...item, id: genId('KT') }]);
  };
  const updateKontrak = (id: string, item: Omit<KontrakPekerjaan, 'id'>) => {
    setKontrakList((prev) => prev.map((kt) => (kt.id === id ? { ...item, id } : kt)));
  };
  const deleteKontrak = (id: string) => {
    setKontrakList((prev) => prev.filter((kt) => kt.id !== id));
  };

  // CRUD SPM
  const addSpm = (item: Omit<RegisterSpm, 'id'>) => {
    setSpmList((prev) => [...prev, { ...item, id: genId('SPM') }]);
  };
  const updateSpm = (id: string, item: Omit<RegisterSpm, 'id'>) => {
    setSpmList((prev) => prev.map((s) => (s.id === id ? { ...item, id } : s)));
  };
  const deleteSpm = (id: string) => {
    setSpmList((prev) => prev.filter((s) => s.id !== id));
  };

  // GAS Config
  const updateGasConfig = (config: Partial<GasConfig>) => {
    setGasConfig((prev) => ({ ...prev, ...config }));
  };

  // Sync Web -> Google Spreadsheet
  const syncWebToSpreadsheet = async (): Promise<boolean> => {
    if (!gasConfig.webAppUrl) {
      setSyncStatusMessage({
        type: 'error',
        text: 'URL Apps Script belum diatur. Masukkan Web App URL di Master Data > Integrasi Spreadsheet.',
      });
      return false;
    }

    setIsSyncing(true);
    setSyncStatusMessage({ type: 'info', text: 'Mengirim data ke Google Spreadsheet...' });

    try {
      const payload = {
        action: 'sync_all',
        data: {
          bidang: bidangList,
          program: programList,
          kegiatan: kegiatanList,
          subkegiatan: subKegiatanList,
          rekening: rekeningList,
          kontrak: kontrakList,
          spm: spmList,
          user: [user],
        },
      };

      const response = await fetch(gasConfig.webAppUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'text/plain;charset=utf-8',
        },
        body: JSON.stringify(payload),
      });

      const resJson = await response.json();
      if (resJson.status === 'success') {
        const now = new Date().toLocaleTimeString('id-ID');
        updateGasConfig({ lastSyncedAt: now });
        setSyncStatusMessage({
          type: 'success',
          text: `Berhasil mengupdate data ke Google Spreadsheet jam ${now}!`,
        });
        setIsSyncing(false);
        return true;
      } else {
        throw new Error(resJson.message || 'Gagal menyimpan ke Google Spreadsheet');
      }
    } catch (err: any) {
      console.error(err);
      setSyncStatusMessage({
        type: 'error',
        text: `Gagal sync: ${err.message || 'Periksa URL Apps Script & Izin Akses "Anyone"'}`,
      });
      setIsSyncing(false);
      return false;
    }
  };

  // Sync Google Spreadsheet -> Web
  const syncSpreadsheetToWeb = async (): Promise<boolean> => {
    if (!gasConfig.webAppUrl) {
      setSyncStatusMessage({
        type: 'error',
        text: 'URL Apps Script belum diatur. Masukkan Web App URL di Master Data > Integrasi Spreadsheet.',
      });
      return false;
    }

    setIsSyncing(true);
    setSyncStatusMessage({
      type: 'info',
      text: 'Mengambil data terbaru dari Google Spreadsheet...',
    });

    try {
      const response = await fetch(gasConfig.webAppUrl);
      const resJson = await response.json();

      if (resJson.status === 'success' && resJson.data) {
        const d = resJson.data;
        if (d.bidang && d.bidang.length > 0) setBidangList(d.bidang);
        if (d.program && d.program.length > 0) setProgramList(d.program);
        if (d.kegiatan && d.kegiatan.length > 0) setKegiatanList(d.kegiatan);
        if (d.subkegiatan && d.subkegiatan.length > 0) setSubKegiatanList(d.subkegiatan);
        if (d.rekening && d.rekening.length > 0) setRekeningList(d.rekening);
        if (d.kontrak && d.kontrak.length > 0) setKontrakList(d.kontrak);
        if (d.spm && d.spm.length > 0) setSpmList(d.spm);
        if (d.user && d.user.length > 0) {
          setUser(d.user[0]);
          localStorage.setItem('REG_SPM_USER', JSON.stringify(d.user[0]));
        }

        const now = new Date().toLocaleTimeString('id-ID');
        updateGasConfig({ lastSyncedAt: now });
        setSyncStatusMessage({
          type: 'success',
          text: `Data web berhasil diperbarui dari Google Spreadsheet jam ${now}!`,
        });
        setIsSyncing(false);
        return true;
      } else {
        throw new Error(resJson.message || 'Format data spreadsheet tidak valid');
      }
    } catch (err: any) {
      console.error(err);
      setSyncStatusMessage({
        type: 'error',
        text: `Gagal mengambil data: ${err.message || 'Periksa koneksi/URL Apps Script'}`,
      });
      setIsSyncing(false);
      return false;
    }
  };

  return (
    <AppContext.Provider
      value={{
        currentView,
        setCurrentView,
        activeTab: currentView,
        setActiveTab: setCurrentView,
        sidebarOpen,
        setSidebarOpen,
        isLoginModalOpen,
        setIsLoginModalOpen,

        selectedYear,
        setSelectedYear,
        user,
        isLoggedIn,
        login,
        logout,
        updateUserCredentials,

        bidangList,
        addBidang,
        updateBidang,
        deleteBidang,

        programList,
        addProgram,
        updateProgram,
        deleteProgram,

        kegiatanList,
        addKegiatan,
        updateKegiatan,
        deleteKegiatan,

        subKegiatanList,
        addSubKegiatan,
        updateSubKegiatan,
        deleteSubKegiatan,

        rekeningList,
        addRekening,
        updateRekening,
        deleteRekening,

        kontrakList,
        addKontrak,
        updateKontrak,
        deleteKontrak,

        spmList,
        addSpm,
        updateSpm,
        deleteSpm,

        gasConfig,
        updateGasConfig,
        isSyncing,
        syncStatusMessage,
        syncWebToSpreadsheet,
        syncSpreadsheetToWeb,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
